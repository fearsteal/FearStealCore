package com.fearsteal.core;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class FearStealCore extends JavaPlugin implements Listener {
    private final Map<UUID, Profile> profiles = new HashMap<>();
    private final Map<String, Long> pairCooldowns = new HashMap<>();
    private final Map<UUID, Long> killerCooldowns = new HashMap<>();
    private File dataFolder;

    private static final class Profile {
        String fear = "WATER";
        final LinkedHashSet<String> blessings = new LinkedHashSet<>();
        final LinkedHashSet<String> curses = new LinkedHashSet<>();
        long kills;
        long deaths;
    }
    private static final class Menu implements InventoryHolder {
        final String type; final UUID target;
        Inventory inventory;
        Menu(String type, UUID target) { this.type = type; this.target = target; }
        @Override public Inventory getInventory() { return inventory; }
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        dataFolder = new File(getDataFolder(), "players");
        if (!dataFolder.exists() && !dataFolder.mkdirs()) getLogger().warning("Could not create player data directory.");
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("fsc")).setExecutor(this);
        for (Player p : Bukkit.getOnlinePlayers()) loadProfile(p.getUniqueId());
        getLogger().info("FearStealCore enabled. Configurable traits and menus loaded.");
    }
    @Override public void onDisable() { for (UUID id : new ArrayList<>(profiles.keySet())) saveProfile(id); }

    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
    private String msg(String key) { return color(getConfig().getString("messages.prefix", "") + getConfig().getString("messages." + key, "")); }
    private void tell(CommandSender sender, String key) { sender.sendMessage(msg(key)); }
    private void tellRaw(CommandSender sender, String message) { sender.sendMessage(color(getConfig().getString("messages.prefix", "") + message)); }
    private Profile profile(UUID id) { return profiles.computeIfAbsent(id, ignored -> { Profile p = new Profile(); p.fear = getConfig().getString("settings.default-fear", "WATER"); return p; }); }

    private void loadProfile(UUID id) {
        File file = new File(dataFolder, id + ".yml");
        Profile p = new Profile();
        if (file.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
            p.fear = y.getString("fear", getConfig().getString("settings.default-fear", "WATER"));
            p.blessings.addAll(y.getStringList("blessings")); p.curses.addAll(y.getStringList("curses"));
            p.kills = y.getLong("kills", 0); p.deaths = y.getLong("deaths", 0);
        } else p.fear = getConfig().getString("settings.default-fear", "WATER");
        profiles.put(id, p);
    }
    private void saveProfile(UUID id) {
        Profile p = profiles.get(id); if (p == null) return;
        File file = new File(dataFolder, id + ".yml"); YamlConfiguration y = new YamlConfiguration();
        y.set("fear", p.fear); y.set("blessings", new ArrayList<>(p.blessings)); y.set("curses", new ArrayList<>(p.curses)); y.set("kills", p.kills); y.set("deaths", p.deaths);
        try { y.save(file); } catch (IOException ex) { getLogger().severe("Could not save profile " + id + ": " + ex.getMessage()); }
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) { loadProfile(e.getPlayer().getUniqueId()); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("menu") || args[0].equalsIgnoreCase("profile")) {
            if (!(sender instanceof Player player)) { tell(sender, "player-only"); return true; }
            if (!player.hasPermission("fearstealcore.use")) { tell(player, "no-permission"); return true; }
            loadIfNeeded(player.getUniqueId()); openPlayerMenu(player); return true;
        }
        if (args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(color("&d&lFearStealCore &7Commands: &f/fsc menu, /fsc profile, /fsc admin, /fsc reload"));
            sender.sendMessage(color("&7Admin: /fsc admin player <name>, fear <player> <trait>, blessing <player> <trait>, curse <player> <trait>, clear <player>, settings")); return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("fearstealcore.admin")) { tell(sender, "no-permission"); return true; }
            reloadConfig(); tell(sender, "reload"); return true;
        }
        if (args[0].equalsIgnoreCase("admin")) {
            if (!sender.hasPermission("fearstealcore.admin")) { tell(sender, "no-permission"); return true; }
            if (args.length == 1 || args[1].equalsIgnoreCase("menu")) {
                if (!(sender instanceof Player p)) { sender.sendMessage("Console: /fsc admin player <online-player>"); return true; }
                openAdminMenu(p); return true;
            }
            if (args[1].equalsIgnoreCase("player") && args.length >= 3) {
                Player target = Bukkit.getPlayerExact(args[2]);
                if (target == null) { tell(sender, "invalid-player"); return true; }
                loadIfNeeded(target.getUniqueId());
                if (sender instanceof Player p) openTargetMenu(p, target.getUniqueId()); else showProfile(sender, target);
                return true;
            }
            if (args[1].equalsIgnoreCase("settings")) {
                sender.sendMessage(color("&dOpposite-action-chance: &f" + getConfig().getDouble("settings.opposite-action-chance", 15) + "%"));
                sender.sendMessage(color("&7Edit plugins/FearStealCore/config.yml, then run /fsc reload.")); return true;
            }
            if (args[1].equalsIgnoreCase("fear") && args.length >= 4) return setTrait(sender, args[2], "fear", args[3]);
            if (args[1].equalsIgnoreCase("blessing") && args.length >= 4) return setTrait(sender, args[2], "blessing", args[3]);
            if (args[1].equalsIgnoreCase("curse") && args.length >= 4) return setTrait(sender, args[2], "curse", args[3]);
            if (args[1].equalsIgnoreCase("clear") && args.length >= 3) {
                Player target = Bukkit.getPlayerExact(args[2]); if (target == null) { tell(sender, "invalid-player"); return true; }
                Profile pr = profile(target.getUniqueId()); pr.fear = "NONE"; pr.blessings.clear(); pr.curses.clear(); saveProfile(target.getUniqueId()); tell(sender, "saved"); return true;
            }
            sender.sendMessage(color("&cUsage: /fsc admin [player <name>|settings|fear <player> <trait>|blessing <player> <trait>|curse <player> <trait>|clear <player>]")); return true;
        }
        tellRaw(sender, "&cUnknown subcommand. Use /fsc help."); return true;
    }
    private void loadIfNeeded(UUID id) { if (!profiles.containsKey(id)) loadProfile(id); }
    private boolean setTrait(CommandSender sender, String name, String kind, String trait) {
        Player target = Bukkit.getPlayerExact(name); if (target == null) { tell(sender, "invalid-player"); return true; }
        String section = kind.equals("fear") ? "traits.fears" : kind.equals("blessing") ? "traits.blessings" : "traits.curses";
        ConfigurationSection sec = getConfig().getConfigurationSection(section);
        if (sec == null || !sec.contains(trait.toUpperCase(Locale.ROOT))) { tellRaw(sender, "&cUnknown " + kind + " trait: " + trait); return true; }
        Profile p = profile(target.getUniqueId()); String value = trait.toUpperCase(Locale.ROOT);
        if (kind.equals("fear")) p.fear = value;
        else if (kind.equals("blessing")) p.blessings.add(value); else p.curses.add(value);
        saveProfile(target.getUniqueId()); tell(sender, "saved"); return true;
    }
    private void showProfile(CommandSender sender, Player target) {
        Profile p = profile(target.getUniqueId()); sender.sendMessage(color("&d" + target.getName() + " &7Fear: &f" + p.fear + " &7Blessings: &f" + p.blessings + " &7Curses: &f" + p.curses));
    }

    private ItemStack item(String materialName, String name, List<String> lore) {
        Material material = Material.matchMaterial(materialName == null ? "PAPER" : materialName);
        if (material == null || !material.isItem()) material = Material.PAPER;
        ItemStack stack = new ItemStack(material); ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(color(name)); List<String> colored = new ArrayList<>(); for (String line : lore) colored.add(color(line)); meta.setLore(colored); meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS); stack.setItemMeta(meta); return stack;
    }
    private String display(String section, String trait) { return color(getConfig().getString(section + "." + trait + ".display", "&f" + trait)); }
    private String material(String section, String trait) { return getConfig().getString(section + "." + trait + ".material", "PAPER"); }
    private String description(String section, String trait) { return getConfig().getString(section + "." + trait + ".description", ""); }
    private void openPlayerMenu(Player p) {
        Menu menu = new Menu("player", p.getUniqueId()); Inventory inv = Bukkit.createInventory(menu, 27, color("&5&lFearStealCore &8» &dProfile")); menu.inventory = inv;
        Profile pr = profile(p.getUniqueId());
        inv.setItem(10, item(material("traits.fears", pr.fear), "&dYour Fear: " + display("traits.fears", pr.fear), List.of("&7" + description("traits.fears", pr.fear), "&eClick to view fears")));
        inv.setItem(12, item("GOLDEN_APPLE", "&aBlessings &7(" + pr.blessings.size() + ")", List.of("&7" + pr.blessings, "&eClick to view blessings")));
        inv.setItem(14, item("WITHER_ROSE", "&cCurses &7(" + pr.curses.size() + ")", List.of("&7" + pr.curses, "&eClick to view curses")));
        inv.setItem(16, item("PLAYER_HEAD", "&bProfile Statistics", List.of("&7Kills: &f" + pr.kills, "&7Deaths: &f" + pr.deaths, "&7Fear: &f" + pr.fear)));
        p.openInventory(inv);
    }
    private void openAdminMenu(Player p) {
        Menu menu = new Menu("admin", p.getUniqueId()); Inventory inv = Bukkit.createInventory(menu, 27, color("&4&lFSC Admin Control")); menu.inventory = inv;
        inv.setItem(10, item("PLAYER_HEAD", "&cManage Online Player", List.of("&7Click to select an online player")));
        inv.setItem(12, item("REDSTONE", "&eGameplay Settings", List.of("&7Opposite chance: " + getConfig().getDouble("settings.opposite-action-chance", 15) + "%", "&7Edit config.yml and use /fsc reload")));
        inv.setItem(14, item("COMPARATOR", "&bReload Configuration", List.of("&eClick to reload config.yml")));
        inv.setItem(16, item("BOOK", "&dTrait Reference", List.of("&7Traits are defined in config.yml")));
        p.openInventory(inv);
    }
    private void openTargetMenu(Player p, UUID targetId) {
        Player target = Bukkit.getPlayer(targetId); if (target == null) { tell(p, "invalid-player"); return; }
        Menu menu = new Menu("target", targetId); Inventory inv = Bukkit.createInventory(menu, 27, color("&4Manage: &f" + target.getName())); menu.inventory = inv;
        Profile pr = profile(targetId);
        inv.setItem(10, item(material("traits.fears", pr.fear), "&dSet Fear", List.of("&7Current: " + pr.fear, "&eClick to choose")));
        inv.setItem(12, item("GOLDEN_APPLE", "&aBlessings", List.of("&7Current: " + pr.blessings, "&eClick to add/remove")));
        inv.setItem(14, item("WITHER_ROSE", "&cCurses", List.of("&7Current: " + pr.curses, "&eClick to add/remove")));
        inv.setItem(16, item("BARRIER", "&cClear Profile Traits", List.of("&eClick to clear Fear, Blessings, Curses")));
        inv.setItem(22, item("PAPER", "&bProfile Stats", List.of("&7Kills: " + pr.kills, "&7Deaths: " + pr.deaths)));
        p.openInventory(inv);
    }
    private void openTraitMenu(Player p, UUID target, String kind) {
        String section = kind.equals("fear") ? "traits.fears" : kind.equals("blessing") ? "traits.blessings" : "traits.curses";
        ConfigurationSection sec = getConfig().getConfigurationSection(section); if (sec == null) return;
        List<String> keys = new ArrayList<>(sec.getKeys(false)); int size = Math.min(54, Math.max(9, ((keys.size() + 8) / 9) * 9));
        Menu menu = new Menu("traits:" + kind, target); Inventory inv = Bukkit.createInventory(menu, size, color("&5Choose " + kind)); menu.inventory = inv;
        for (int i = 0; i < Math.min(keys.size(), size); i++) { String key = keys.get(i); inv.setItem(i, item(material(section, key), display(section, key), List.of("&7" + description(section, key), "&eClick to toggle/apply", "&8Trait: " + key))); }
        p.openInventory(inv);
    }

    @EventHandler public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Menu menu)) return;
        e.setCancelled(true); if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getRawSlot(); if (slot < 0 || slot >= e.getView().getTopInventory().getSize()) return;
        if (menu.type.equals("player")) {
            if (slot == 10) openTraitReadMenu(p, "traits.fears", "Your Fear");
            else if (slot == 12) openTraitReadMenu(p, "traits.blessings", "Your Blessings");
            else if (slot == 14) openTraitReadMenu(p, "traits.curses", "Your Curses");
            return;
        }
        if (!p.hasPermission("fearstealcore.admin")) { p.closeInventory(); tell(p, "no-permission"); return; }
        if (menu.type.equals("admin")) {
            if (slot == 10) openOnlinePlayers(p);
            else if (slot == 12) { p.closeInventory(); p.sendMessage(color("&dEdit settings in plugins/FearStealCore/config.yml. Current opposite chance: &f" + getConfig().getDouble("settings.opposite-action-chance", 15) + "%")); }
            else if (slot == 14) { reloadConfig(); tell(p, "reload"); openAdminMenu(p); }
            else if (slot == 16) { p.closeInventory(); p.sendMessage(color("&7Configured trait keys: see config.yml under traits.fears, traits.blessings and traits.curses.")); }
        } else if (menu.type.equals("online")) {
            ItemStack clicked = e.getCurrentItem(); if (clicked == null || !clicked.hasItemMeta() || clicked.getItemMeta().getLore() == null) return;
            String name = ChatColor.stripColor(clicked.getItemMeta().getDisplayName()); Player target = Bukkit.getPlayerExact(name);
            if (target != null) openTargetMenu(p, target.getUniqueId());
        } else if (menu.type.equals("target")) {
            if (slot == 10) openTraitMenu(p, menu.target, "fear"); else if (slot == 12) openTraitMenu(p, menu.target, "blessing"); else if (slot == 14) openTraitMenu(p, menu.target, "curse");
            else if (slot == 16) { Profile pr = profile(menu.target); pr.fear = "NONE"; pr.blessings.clear(); pr.curses.clear(); saveProfile(menu.target); tell(p, "saved"); openTargetMenu(p, menu.target); }
        } else if (menu.type.startsWith("traits:")) {
            ItemStack clicked = e.getCurrentItem(); if (clicked == null || !clicked.hasItemMeta() || clicked.getItemMeta().getLore() == null) return;
            List<String> lore = clicked.getItemMeta().getLore(); if (lore.size() < 3) return;
            String trait = ChatColor.stripColor(lore.get(2)).replace("Trait: ", "").trim(); String kind = menu.type.substring("traits:".length()); Profile pr = profile(menu.target);
            if (kind.equals("fear")) pr.fear = trait;
            else if (kind.equals("blessing")) { if (!pr.blessings.remove(trait)) { if (pr.blessings.size() >= getConfig().getInt("settings.max-blessings", 3)) { tellRaw(p, "&cBlessing limit reached."); return; } pr.blessings.add(trait); } }
            else { if (!pr.curses.remove(trait)) { if (pr.curses.size() >= getConfig().getInt("settings.max-curses", 3)) { tellRaw(p, "&cCurse limit reached."); return; } pr.curses.add(trait); } }
            saveProfile(menu.target); tell(p, "saved"); openTargetMenu(p, menu.target);
        }
    }
    private void openOnlinePlayers(Player p) {
        Menu menu = new Menu("online", p.getUniqueId()); int size = Math.min(54, Math.max(9, ((Bukkit.getOnlinePlayers().size() + 8) / 9) * 9));
        Inventory inv = Bukkit.createInventory(menu, size, color("&4Select Online Player")); menu.inventory = inv; int i = 0;
        for (Player target : Bukkit.getOnlinePlayers()) { if (i >= size) break; inv.setItem(i++, item("PLAYER_HEAD", "&f" + target.getName(), List.of("&7Click to manage this player"))); }
        p.openInventory(inv);
    }
    private void openTraitReadMenu(Player p, String section, String title) {
        ConfigurationSection sec = getConfig().getConfigurationSection(section); if (sec == null) return;
        List<String> keys = new ArrayList<>(sec.getKeys(false)); Menu menu = new Menu("readonly", p.getUniqueId()); Inventory inv = Bukkit.createInventory(menu, Math.min(54, Math.max(9, ((keys.size()+8)/9)*9)), color("&5" + title)); menu.inventory = inv;
        Profile pr = profile(p.getUniqueId()); for (int i=0; i<Math.min(keys.size(), inv.getSize()); i++) { String key=keys.get(i); boolean active=section.endsWith("fears") ? pr.fear.equals(key) : section.endsWith("blessings") ? pr.blessings.contains(key) : pr.curses.contains(key); inv.setItem(i, item(material(section,key), display(section,key), List.of("&7"+description(section,key), active ? "&aCurrently active" : "&8Not active"))); }
        p.openInventory(inv);
    }
    @EventHandler public void onInventoryDrag(InventoryDragEvent e) { if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true); }

    @EventHandler public void onPlayerDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity(); Player killer = victim.getKiller(); Profile victimProfile = profile(victim.getUniqueId()); victimProfile.deaths++; saveProfile(victim.getUniqueId());
        if (killer == null || killer.equals(victim) || !getConfig().getBoolean("settings.enabled", true)) return;
        if (killer.hasPermission("fearstealcore.admin") && getConfig().getBoolean("settings.ignore-admin-kills", false)) return;
        long now = System.currentTimeMillis(); long cooldown = Math.max(0, getConfig().getLong("settings.same-victim-cooldown-seconds", 3600)) * 1000L;
        String pair = killer.getUniqueId() + ":" + victim.getUniqueId(); Long last = pairCooldowns.get(pair);
        if (last != null && now - last < cooldown) { killer.sendMessage(msg("cooldown")); return; }
        long globalCooldown = Math.max(0, getConfig().getLong("settings.kill-cooldown-seconds", 60)) * 1000L; Long lastKill = killerCooldowns.get(killer.getUniqueId());
        if (lastKill != null && now - lastKill < globalCooldown) { killer.sendMessage(msg("cooldown")); return; }
        pairCooldowns.put(pair, now); killerCooldowns.put(killer.getUniqueId(), now);
        Profile kp = profile(killer.getUniqueId()); String oldKillerFear = kp.fear; String stolenFear = victimProfile.fear;
        if (getConfig().getBoolean("settings.transfer-fear-on-kill", true)) { kp.fear = stolenFear; victimProfile.fear = oldKillerFear; }
        kp.kills++;
        double opposite = Math.max(0, Math.min(100, getConfig().getDouble("settings.opposite-action-chance", 15.0)));
        if (Math.random() * 100 < opposite) {
            killer.sendMessage(msg("opposite-action"));
            // Opposite action: replace the normal blessing reward with a curse penalty.
            if (getConfig().getBoolean("settings.apply-curse-penalty-on-kill", true)) addRandomCurse(kp);
        } else {
            if (getConfig().getBoolean("settings.grant-blessing-on-kill", true)) addRandomBlessing(kp);
            if (getConfig().getBoolean("settings.apply-curse-penalty-on-kill", true) && Math.random()*100 < Math.max(0, Math.min(100, getConfig().getDouble("settings.penalty-chance",25)))) addRandomCurse(kp);
        }
        applyTraits(killer, kp);
        saveProfile(killer.getUniqueId()); saveProfile(victim.getUniqueId());
        killer.sendMessage(color(getConfig().getString("messages.prefix", "") + getConfig().getString("messages.kill-steal", "").replace("{fear}", stolenFear).replace("{victim}", victim.getName())));
        victim.sendMessage(color(getConfig().getString("messages.prefix", "") + getConfig().getString("messages.killed", "").replace("{killer}", killer.getName())));
    }
    private void addRandomBlessing(Profile p) {
        if (p.blessings.size() >= getConfig().getInt("settings.max-blessings",3)) return;
        ConfigurationSection sec = getConfig().getConfigurationSection("traits.blessings"); if (sec == null || sec.getKeys(false).isEmpty()) return;
        List<String> keys = new ArrayList<>(sec.getKeys(false)); Collections.shuffle(keys); for (String key : keys) if (p.blessings.add(key)) break;
    }
    private void addRandomCurse(Profile p) {
        if (p.curses.size() >= getConfig().getInt("settings.max-curses",3)) return;
        ConfigurationSection sec = getConfig().getConfigurationSection("traits.curses"); if (sec == null || sec.getKeys(false).isEmpty()) return;
        List<String> keys = new ArrayList<>(sec.getKeys(false)); Collections.shuffle(keys); for (String key : keys) if (p.curses.add(key)) break;
    }
    private void applyTraits(Player player, Profile p) {
        for (String blessing : p.blessings) applyConfiguredEffect(player, "traits.blessings." + blessing);
        for (String curse : p.curses) applyConfiguredEffect(player, "traits.curses." + curse);
    }
    private void applyConfiguredEffect(Player player, String path) {
        String type = getConfig().getString(path + ".effect", ""); if (type.isBlank()) return;
        PotionEffectType effect = PotionEffectType.getByName(type.toUpperCase(Locale.ROOT)); if (effect == null) { getLogger().warning("Unknown potion effect at " + path + ": " + type); return; }
        int duration = Math.max(1, getConfig().getInt(path + ".duration-seconds", 5)) * 20;
        int amplifier = Math.max(0, Math.min(10, getConfig().getInt(path + ".amplifier", 0)));
        player.addPotionEffect(new PotionEffect(effect, duration, amplifier, true, true, true));
    }
}
