# FearStealCore 1.0.0

A configurable Paper plugin source project for the FearStealCore fear-transfer gameplay concept.

## Compatibility

- **Target server range:** Paper **1.21.11 through 26.2** (Minecraft Java Edition).
- **API strategy:** compiled against Paper API `1.21.11-R0.1-SNAPSHOT`, using the shared Bukkit/Paper API and no NMS internals; `plugin.yml` keeps `api-version: '1.21'` so Paper 1.21.11 and later 26.x servers can consider loading it.
- **Build bytecode:** Java 21 (`--release 21`). Java 25 can run Java 21 bytecode.
- **Server runtime:** Java 21 for Paper 1.21.11; Java 25 for Paper 26.2. Use the Java version required by the server itself.
- **Verification status:** this is a compatibility target, **not a claim of tested compatibility**. The plugin has not been compiled or integration-tested here. Test on separate Paper 1.21.11 and Paper 26.2 staging servers before production. Paper 26.x changes APIs and bundled Adventure versions, so rebuild and test if compilation or runtime errors occur.

## Build

Install JDK 21 and Maven 3.9+, then run from this directory. To test on Paper 26.2, the server itself must run on Java 25:

```sh
mvn clean package
```

The resulting plugin JAR will be `target/FearStealCore-1.0.0.jar`. Copy it into your Paper server's `plugins/` directory and restart the server. The JAR is not included in this source archive because this environment had no Maven installation or network access to retrieve Maven/Paper API dependencies, so a genuine plugin binary could not be compiled here.

## First run

1. Start a Paper server once with the plugin JAR installed.
2. Edit `plugins/FearStealCore/config.yml` to tune traits, messages, probabilities, cooldowns and effects.
3. Restart or run `/fsc reload` after editing `config.yml`.
4. Grant administrators `fearstealcore.admin`; regular players use `fearstealcore.use`.

## Commands

- `/fsc` or `/fsc menu` — player profile menu
- `/fsc profile` — opens the same player menu
- `/fsc help` — command help
- `/fsc admin` — admin control GUI
- `/fsc admin player <online-player>` — manage an online player
- `/fsc admin settings` — show current probability/config hint
- `/fsc admin fear <online-player> <trait>` — assign a Fear
- `/fsc admin blessing <online-player> <trait>` — add a Blessing
- `/fsc admin curse <online-player> <trait>` — add a Curse
- `/fsc admin clear <online-player>` — clear Fear, Blessings and Curses
- `/fsc reload` — reload `config.yml` (admin permission required)

Trait names are the keys under `traits.fears`, `traits.blessings` and `traits.curses` in `config.yml`, e.g. `WATER`, `SWIFTNESS`, `WEAKNESS`.

## Data and safeguards

Player profiles are stored in `plugins/FearStealCore/players/<uuid>.yml`. The implementation cancels item movement in plugin menus, validates the top-inventory click target, checks the admin permission for admin menu actions, caps GUI-assigned Blessings/Curses, and applies per-killer plus per-killer/victim cooldowns. The same-IP option is reserved in configuration but is not implemented in this release. Data is saved on joins/deaths, profile edits and plugin shutdown.

## Current implementation scope / verification status

This is a source project, not a certified release. The environment used to prepare it did not have Maven installed and could not resolve external hosts, so compilation against Paper API and live-server integration tests could not be run. Before production use, build with Maven and test on a disposable Paper server. In particular, verify GUI flows, potion-effect names for your Paper build, persistence after restart, kill cooldowns and the intended interpretation of the opposite-action mechanic. Do not treat the project as tested or production-certified until those checks pass.
